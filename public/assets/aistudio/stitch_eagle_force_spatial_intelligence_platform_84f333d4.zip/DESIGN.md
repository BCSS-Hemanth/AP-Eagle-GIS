---
name: EAGLE Force Command & Spatial Intelligence
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#090051'
  on-tertiary: '#ffffff'
  tertiary-container: '#17008c'
  on-tertiary-container: '#837fff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
  code-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes an authoritative, high-density geospatial intelligence and tactical monitoring interface for enterprise law enforcement operations. The visual narrative combines the disciplined restraint of defense-grade command consoles with the modern legibility of high-performance GIS platforms.

### Visual Aesthetic & Philosophy
- **Style Archetype:** Precision Corporate & Mission-Critical Functionalism. Minimal visual ornamentation, zero ambient fluff, and extreme emphasis on operational clarity, structural hierarchy, and information density.
- **Emotional Resonance:** Authoritative, uncompromisingly dependable, hyper-vigilant, and calm under operational stress.
- **Density Philosophy:** High information density optimized for multi-screen operations centers, spatial analysts, and tactical decision-makers. Layout elements prioritize low vertical footprints, clear separation of control surfaces, and uncluttered cartographic canvases.
- **Map-First Architecture:** The cartographic canvas is the primary viewport; all surrounding UI chrome (collapsible side panels, floating control docks, attribute tables, and metric HUDs) acts as structured framing that never obscures situational awareness.

## Colors

The palette is engineered for prolonged operational viewing in command centers and bright field environments. It relies on crisp slate and pure white base surfaces to maintain contrast against satellite, topographic, and vector basemaps.

### Palette Architecture
- **Primary (`#0F2942`):** Command Navy. Anchors top application bars, active workspace boundaries, master structural borders, and critical action buttons. Conveys institutional authority and security.
- **Secondary (`#0D9488`):** Enforcement Teal. Used for active geospatial vector layers, selected polygon boundaries, spatial filter toggles, and primary analytical highlights.
- **Tertiary (`#4F46E5`):** Spatial Intelligence Indigo. Dedicated to algorithmic tools, clustering controls, buffer/isochrone visualizers, and spatial query builders.
- **Neutral Palette:**
  - `Canvas White` (`#FFFFFF`): Panel bodies, attribute table cells, card bases.
  - `Slate Tint Base` (`#F8FAFC`): Outer viewport underlays, inactive panel backgrounds, alternating table rows.
  - `Muted Surface` (`#F1F5F9`): Tool bars, control header strips, input background states.
  - `Hairline Border` (`#E2E8F0`): Primary structural borders and panel separators.
  - `Command Neutral` (`#64748B`): Secondary text, disabled icons, spatial metadata labels.
  - `Ink Heavy` (`#0F172A`): Primary body text, coordinate values, and critical metrics.

### Tactical Status Tones (Functional Semantics)
- **Operational / Verified (`#059669`):** Patrols active, checkpoints verified, cleared zones.
- **Flagged / Pending (`#D97706`):** Anomalies, unresolved spatial alerts, warning thresholds.
- **Critical / Hotspot / Seizure (`#DC2626`):** Red zones, urgent alerts, spatial contraband detections, boundary breaches.
- **Telemetry / Geofence Inactive (`#94A3B8`):** Offline beacons, deactivated tracking layers.

## Typography

The type system is powered by **Inter**, chosen for its extreme legibility at low point sizes and robust native OpenType feature support.

### Typographic Rules & Numerical Rigor
- **Tabular Figures (`tnum`):** All numeric displays, geospatial coordinates (Latitude/Longitude, UTM, MGRS), telemetry feeds, timestamps (IST / UTC), and statistical count-ups must enforce `font-feature-settings: "tnum" 1`. This prevents layout shifts during real-time GPS polling.
- **Slashed Zero (`zero`):** Activated for coordinate readouts and reference codes to eliminate ambiguity between `0` and `O`.
- **Micro-Labels:** Metadata identifiers, layer group titles, and coordinate axis indicators utilize `label-sm` or `label-md` with uppercase styling and expanded letter spacing (`+0.05em`) for immediate recognition across dense HUD elements.
- **Mobile Optimization:** On mobile displays (<768px), `headline-lg` shifts down to 20px / 26px line height to preserve screen real estate on tactical handoffs.

## Layout & Spacing

The layout operates on an uncompromising, high-density 4px base increment system to balance rich GIS operational controls against visual order.

### Layout Architecture
- **Desktop (>=1280px):** Fixed-edge split-pane framework. 
  - **Global Header:** 48px fixed height.
  - **Left Rail (Layers / Legend / Queries):** Collapsible 320px to 380px panel.
  - **Central Viewport:** Dynamic 100% fluid map viewport with floating HUD overlays.
  - **Right Drawer (Feature Intel / Inspector):** Collapsible 360px contextual panel.
  - **Bottom Drawer (Attribute Table):** Resizable 240px to 480px dockable panel with pagination and spatial filter bindings.
- **Tablet (768px - 1279px):** Left navigation collapses to an off-canvas overlay or compact 56px icon bar. Bottom table switches to a modal or full-viewport slide-over.
- **Mobile Handheld (<768px):** Single-column stacked mode. The map takes 100% of the screen with a bottom swipe sheet for quick incident dispatch, alert summaries, and essential filter chips.

### Spacing Philosophy
- Controls, table rows, and tool list items use compact vertical padding (`space-xs` to `space-sm`) to maximize visible records per viewport.
- Section margins and panel insets leverage `space-md` to `space-lg` to prevent visual fatigue.

## Elevation & Depth

Visual hierarchy in this system is achieved via **tonal layering and crisp low-contrast borders** rather than deep cinematic shadows. This keeps the user focused on vector symbology and satellite imagery without peripheral blur.

### Depth Hierarchy
- **Level 0 (Map Floor):** Basemap layer, satellite feeds, vector tiles.
- **Level 1 (Docked Structural Surfaces):** Top navigation bar, pinned left layer tree, docked bottom attribute table. Styled with a crisp 1px solid border (`#E2E8F0`), zero shadow, and background color `#FFFFFF`.
- **Level 2 (Floating Map HUD & Toolstrips):** Zoom controls, measurement tools, basemap switcher, polygon drawing toolbars. Styled with 1px border (`#CBD5E1`) and a tight tactical shadow: `0 1px 3px 0 rgba(15, 41, 66, 0.08), 0 1px 2px -1px rgba(15, 41, 66, 0.05)`.
- **Level 3 (Context Overlays & Popovers):** Coordinate inspector popovers, feature details, quick contextual filters: `0 4px 6px -1px rgba(15, 41, 66, 0.1), 0 2px 4px -2px rgba(15, 41, 66, 0.06)`.
- **Level 4 (Critical Alert Modals & System Diagnostics):** Emergency incident alerts, layer export configuration: `0 12px 24px -4px rgba(15, 41, 66, 0.16)`.

## Shapes

The design system employs a **Soft (Level 1)** corner radius language. 

### Corner Radii Guidelines
- **Core Controls & Buttons:** 4px (`0.25rem`). Maintains an instrument-grade, structured feel that aligns cleanly with dense tabular columns and GIS coordinate fields.
- **Panels, Flyouts, Cards & Floating Docks:** 6px to 8px (`rounded-lg`). Provides subtle softness without yielding a playful or casual consumer appearance.
- **Badges, Status Nodes & Alert Pills:** 9999px (Fully pill-shaped) strictly for operational status indicators, severity pills, and incident counters to immediately distinguish state metadata from interactive buttons.

## Components

### Buttons
- **Primary Command:** Solid `#0F2942` with `#FFFFFF` text. Minimal padding (6px 12px for compact, 8px 16px for standard). Hover state tints to `#1E3A5F`. Focused with a high-contrast 2px `#0D9488` ring offset.
- **Secondary Tool:** Border 1px `#CBD5E1`, background `#FFFFFF`, text `#0F2942`. Active/selected state switches to background `#F1F5F9` with border `#0F2942`.
- **Tactical Action (Alert / Seizure):** Solid `#DC2626` background with crisp white typography for immediate field dispatch or incident escalation.

### Map Controls & Floating Docks
- Grouped tool palettes (pan, polygon select, distance measure, buffer ring) sit in unified vertically stacked containers with 1px internal dividers (`#E2E8F0`). Active tools receive a `#0F2942` icon tint and a `#F1F5F9` background with a left 3px indicator line in `#0D9488`.

### Status Badges & Chips
- High-contrast, semantic status chips:
  - **Operational:** Background `#ECFDF5`, text `#065F46`, border 1px `#A7F3D0`, dot indicator `#059669`.
  - **Pending / Amber:** Background `#FFFBEB`, text `#92400E`, border 1px `#FDE68A`, dot indicator `#D97706`.
  - **Hotspot / Critical:** Background `#FEF2F2`, text `#991B1B`, border 1px `#FECACA`, dot indicator `#DC2626`.
  - **Intelligence Layer:** Background `#EEF2FF`, text `#3730A3`, border 1px `#C7D2FE`.

### Attribute Table & Data Grid
- **Header:** Height 32px, background `#F8FAFC`, uppercase `label-md` text in `#64748B`, with 1px border bottom `#CBD5E1`.
- **Data Rows:** Height 32px (compact) or 38px (comfortable). Zebra striping using alternating `#FFFFFF` and `#F8FAFC`. Monospaced tabular numbers for lat/long coordinates, timestamps, and zone codes.
- **Selected Row:** Background tint `#F0FDFA` with a 2px left border accent in `#0D9488`.

### Input Fields & Spatial Query Selectors
- Background `#FFFFFF`, border 1px `#CBD5E1`, 4px radius.
- Height: 32px for compact GIS control panels; 36px for primary form drawers.
- Focus: Border color shifts to `#0F2942` with an external 1px outline in `#0D9488`.

### Collapsible Layer Tree & Legend
- Nested accordion rows with 16px icon slots, visible lock/hide layer eye toggles, opacity sliders with custom `#0F2942` track fills, and color-coded vector swatch glyphs (polygon fills, point symbols, polyline dashes).